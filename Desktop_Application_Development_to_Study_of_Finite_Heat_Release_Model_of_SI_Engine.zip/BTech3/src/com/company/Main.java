package com.company;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public class Main{

    double theta_s, theta_d, gamma, bore, stroke,con_rod, p0, Q,r,R;


    Main(double Theta_s,double Theta_d,double Gamma,double Bore,double Stroke,double Con_rod,double P0,double Qin,double com_ratio){

        theta_s=Math.toRadians(Theta_s);
        theta_d=Math.toRadians(Theta_d);
        gamma=Gamma;
        bore=Bore;
        stroke=Stroke;
        con_rod=Con_rod;
        p0=P0;
        Q=Qin;
        r=com_ratio;

        R=2*con_rod/stroke;

    }

    Main(double Theta_s,double Theta_d){
        theta_s=Theta_s;
        theta_d=Theta_d;
    }

    public double getVd(){
        double Vd=(Math.PI)*bore*bore*stroke/4;
        //System.out.println("Vd="+Vd);
        return Vd;
    }

    public double getXb(double theta){
        double Xb=1-Math.exp(-5*Math.pow((theta-theta_s)/(theta_d),3));
        //System.out.println("Xb="+Xb);
        return Xb;
    }

    public double getV(double theta){
        double V =(getVd()/(r-1))+(getVd()/2)*(R+1-Math.cos(theta)-Math.sqrt(R*R-Math.pow(Math.sin(theta),2)));
        //double V=(1+(r-1)/2*(1-Math.cos(Math.toRadians(theta))))/r;
        //System.out.println("V="+V);
        return V;
    }

    public double getdV(double theta){
        double dV =(getVd()/2)*Math.sin(theta)*(1+Math.cos(theta)/Math.sqrt(R*R-Math.pow(Math.sin(theta),2)));
        //double dV=((r-1)/2)*Math.sin(Math.toRadians(theta))/r;
        //System.out.println("dV="+dV);
        return dV;
    }

    public double getdQ(double theta){
        double dQ=15*(Q/theta_d)*(1-getXb(theta))*Math.pow((theta-theta_s)/(theta_d),2);
        //System.out.println("dQ="+dQ);
        return dQ;
    }

    public double f1(double theta,double p){
        double function=-1.4*p*getdV(theta)/getV(theta);
        return function;
    }

    public double f2(double theta,double p){
        double function=-1.4*p*getdV(theta)/getV(theta)+0.4*getdQ(theta)/getV(theta);
        return function;
    }

}


class LineChart_AWT extends ApplicationFrame
{
    public LineChart_AWT( String applicationTitle , String chartTitle )
    {
        super(applicationTitle);
        JFreeChart lineChart = ChartFactory.createLineChart(
                chartTitle,
                "Crank angle","Pressure",
                createDataset(),
                PlotOrientation.VERTICAL,
                true,true,false);

        ChartPanel chartPanel = new ChartPanel( lineChart );
        chartPanel.setPreferredSize( new java.awt.Dimension( 560 , 367 ) );
        setContentPane( chartPanel );
    }

    private DefaultCategoryDataset createDataset( ){
        Main test=new Main(-20,40,1.4,0.1,0.1,0.15,101325,1800,10);
        double p=101325;
        double k1,k2,k3,k4,p2;

        DefaultCategoryDataset dataset = new DefaultCategoryDataset( );
        dataset.addValue(p,"bar","-180");
        System.out.println(p);
        int i=-180;
        for(double theta=-180*(Math.PI)/180;theta<=-20*(Math.PI)/180;theta=theta+2*(Math.PI)/180){

            k1=test.f1(theta,p);//function;
            //System.out.println("k1="+k1);
            k2=test.f1(theta+1*(Math.PI)/180,p+k1*(Math.PI)/180);
            //System.out.println("k2="+k2);
            k3=test.f1(theta+1*(Math.PI)/180,p+k2*(Math.PI)/180);
            //System.out.println("k3="+k3);
            k4=test.f1(theta+2*(Math.PI)/180,p+2*k3*(Math.PI)/180);
            //System.out.println("k4="+k4);

            p2=p+(k1+2*k2+2*k3+k4)*2*(Math.PI)/(180*6);

            p=p2;
            //System.out.println(theta*180/(Math.PI)+"="+p2);
            dataset.addValue(p2,"bar",Integer.toString(i+2));
            i=i+2;
            System.out.println(p2);
        }

        for(double theta=-20*(Math.PI)/180;theta<=18*(Math.PI)/180;theta=theta+2*(Math.PI)/180){
            k1=test.f2(theta,p);//function;
            //System.out.println("k1="+k1);
            k2=test.f2(theta+1*(Math.PI)/180,p+k1*(Math.PI)/180);
            //System.out.println("k2="+k2);
            k3=test.f2(theta+1*(Math.PI)/180,p+k2*(Math.PI)/180);
            //System.out.println("k3="+k3);
            k4=test.f2(theta+2*(Math.PI)/180,p+2*k3*(Math.PI)/180);
            //System.out.println("k4="+k4);

            p2=p+(k1+2*k2+2*k3+k4)*2*(Math.PI)/(180*6);
            //p2=p+k1*;
            p=p2;

            dataset.addValue(p2,"bar",Integer.toString(i+2));
            //System.out.println(theta*180/(Math.PI)+"="+p2);

            i=i+2;
            System.out.println(p2);
        }

        for(double theta=20*(Math.PI)/180;theta<=180*(Math.PI)/180;theta=theta+2*(Math.PI)/180){

            k1=test.f1(theta,p);//function;
            //System.out.println("k1="+k1);
            k2=test.f1(theta+1*(Math.PI)/180,p+k1*(Math.PI)/180);
            //System.out.println("k2="+k2);
            k3=test.f1(theta+1*(Math.PI)/180,p+k2*(Math.PI)/180);
            //System.out.println("k3="+k3);
            k4=test.f1(theta+2*(Math.PI)/180,p+2*k3*(Math.PI)/180);
            //System.out.println("k4="+k4);

            p2=p+(k1+2*k2+2*k3+k4)*2*(Math.PI)/(180*6);

            p=p2;

            dataset.addValue(p2,"bar",Integer.toString(i+2));
            i=i+2;
            //System.out.println(theta*180/(Math.PI)+"="+p2);
            System.out.println(p2);
        }

        return  dataset;
    }
    public static void main( String[ ] args )
    {
        LineChart_AWT chart = new LineChart_AWT(
                "Pressure vs Crank angle" ,
                "Pressure vs Crank angle");

        chart.pack( );
        RefineryUtilities.centerFrameOnScreen( chart );
        chart.setVisible( true );
    }
}
